<?php

namespace app\Model;

use app\Controller\MyCript;
use Exception;
use PHPMailer\PHPMailer\PHPMailer;


class Mail {


    public static function send () {
        $mail = new PHPMailer(true);

        $host     = 'mail.privateemail.com';
        $username = 'noreply@foxcode.io';
        $password = MyCript::decrypt($_ENV['EMAIL_PASSWORD']);

        try {
            // Server settings
            $mail->isSMTP();                                            
            $mail->Host       = $host;                     
            $mail->SMTPAuth   = true;                                   
            $mail->Username   = $username;           
            $mail->Password   = $password;                              
            $mail->SMTPSecure = 'ssl';         
            $mail->Port       = 465;                                    
    
            //Recipients
            $mail->setFrom($username, $username);
            $mail->addAddress('chris12aug@yahoo.com', 'Recipient Name'); 
    
            //Content
            $mail->isHTML(true);                                  
            $mail->CharSet = 'UTF-8';
            $mail->Subject = 'MyAdmin Email Conferm';
            $mail->Body    =  '<h2>This is the body</h2>';
            $mail->AltBody =  '<h2>This is the body</h2>';
    
    
            $mail->send();
    
            } catch (\Exception $e) {
                throw "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
    }
}

?>





<!-- 





class Mail {

    
    private static $mail;
    private $eMail;


    // _________________________________________________________________


    public function __construct($toEmail='chris12aug@yahoo.com', $toName='Test') {
        
        try {

            if (!self::$mail) self::initMailer();
            $this->eMail = clone self::$mail;
            
            //Recipients
            $this->eMail->setFrom($this->eMail->Username, 'MyAdmin');
            $this->eMail->addAddress($toEmail, $toEmail);        
            
            //Content
            $this->eMail->isHTML(true);                                  
            $this->eMail->Subject = 'Here is the subject';
            $this->eMail->Body    = 'This is the HTML message body <b>in bold!</b>';
            $this->eMail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            
            $this->eMail->send();

        } catch (Exception $e) {
            header('Content-Type: application/json');
            echo $e; echo '<br><br>-----A----<br><br>'; echo $this->eMail->ErrorInfo;
            die();
        }
    }


    // _________________________________________________________________


    public static function initMailer () {

        try {

            $mail = new PHPMailer(true);

            $host = MyCript::decrypt($_ENV['EMAIL_HOST']);
            $username = MyCript::decrypt($_ENV['EMAIL_USERNAME']);
            $password = MyCript::decrypt($_ENV['EMAIL_PASSWORD']);
            
            // $host = 'mail.privateemail.com';
            // $username = 'noreply@foxcode.io';
            // $password = MyCript::decrypt($_ENV['EMAIL_PASSWORD']);

            // echo $password ;
            // die();

            $mail->isSMTP();                                            
            $mail->Host       = $host;                     
            $mail->SMTPAuth   = true;                                   
            $mail->Username   = $username;           
            $mail->Password   = $password;                              
            $mail->SMTPSecure = 'ssl';         
            $mail->Port       = 465;  

            // $mail->setFrom($username, 'foxcode9');
            // $mail->addAddress('chris12aug@yahoo.com', 'Chis');
            // $mail->CharSet = 'UTF-8';
            // $mail->Subject = 'zzzzzzz';
            // $mail->Body    =  '123';
            // $mail->AltBody =  '456';
            // $mail->send();
            // die();

            self::$mail = $mail;

        } catch (Exception $e) {
            header('Content-Type: application/json');
            echo $e; echo '<br><br>----------<br><br>'; echo $mail->ErrorInfo;
            die();
        }
    }

    // _________________________________________________________________



}
 -->